INFO212 assignment 04.

Github repository URL: https://github.com/KHelgeland/Oblig4-INFO212
